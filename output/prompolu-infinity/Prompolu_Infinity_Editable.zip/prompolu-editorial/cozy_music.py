"""Original cozy nylon-guitar score; offline FluidSynth, no audio device/API."""
from pathlib import Path
import ctypes as ct,ctypes.util,json,wave,subprocess,hashlib
import numpy as np
P=Path(__file__).resolve().parent
C=json.loads((P/'timeline.json').read_text());sr=48000;duration=15
lib=ct.CDLL(ctypes.util.find_library('fluidsynth') or 'libfluidsynth.so.3')
def bind(name,result,args):
 f=getattr(lib,name);f.restype=result;f.argtypes=args;return f
ptr=ct.c_void_p;I=ct.c_int;D=ct.c_double;S=ct.c_char_p
settings=bind('new_fluid_settings',ptr,[])()
bind('fluid_settings_setnum',I,[ptr,S,D])(settings,b'synth.sample-rate',sr)
lib.fluid_settings_setnum(settings,b'synth.gain',.65)
bind('fluid_settings_setint',I,[ptr,S,I])(settings,b'synth.chorus.active',0)
lib.fluid_settings_setint(settings,b'synth.reverb.active',1)
synth=bind('new_fluid_synth',ptr,[ptr])(settings)
load=bind('fluid_synth_sfload',I,[ptr,S,I]);assert load(synth,str(P/'assets/audio/TimGM6mb.sf2').encode(),1)>=0
bind('fluid_synth_program_change',I,[ptr,I,I])(synth,0,24)
if hasattr(lib,'fluid_synth_set_reverb'):bind('fluid_synth_set_reverb',None,[ptr,D,D,D,D])(synth,.42,.65,60,.20)
on=bind('fluid_synth_noteon',I,[ptr,I,I,I]);off=bind('fluid_synth_noteoff',I,[ptr,I,I]);write=bind('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I])
rng=np.random.default_rng(617);events=[];notes=[]
def note(start,key,hold,velocity):
 start=max(0,start+float(rng.uniform(-.018,.018)));velocity=int(np.clip(velocity+rng.integers(-3,4),1,127))
 events.extend([(round(start*sr),True,key,velocity),(min(sr*15,round((start+hold)*sr)),False,key,0)])
 notes.append({'time':round(start,3),'midi_note':key,'hold':hold,'velocity':velocity})
# Sparse voicings: Dmaj9, Bm7, Gmaj9, Dmaj9; slightly rolled by a human-like hand.
for start,chord in [(0.14,[50,57,61,64]),(4.3,[47,54,57,62]),(8.55,[43,54,57,62]),(12.65,[50,57,61,66])]:
 for j,k in enumerate(chord):note(start+j*.32,k,2.1 if start<12 else 1.25,54+(3 if j==3 else 0))
for start,k,hold,vel in [(1.02,69,1.2,48),(2.62,66,1.5,45),(5.28,64,1.3,46),(6.84,62,1.4,43),(9.42,69,1.35,46),(10.87,66,1.4,43),(13.18,62,1.3,42)]:note(start,k,hold,vel)
events.sort(key=lambda e:(e[0],e[1]));mix=np.zeros((sr*15,2),dtype=np.float32);cursor=0
try:
 for at,is_on,key,vel in events+[(sr*15,False,0,0)]:
  at=min(sr*15,at)
  if at>cursor:
   n=at-cursor;left=np.empty(n,np.float32);right=np.empty(n,np.float32)
   assert write(synth,n,left.ctypes.data,0,1,right.ctypes.data,0,1)==0
   mix[cursor:at,0]=left;mix[cursor:at,1]=right;cursor=at
  if key:(on(synth,0,key,vel) if is_on else off(synth,0,key))
finally:
 bind('delete_fluid_synth',None,[ptr])(synth);bind('delete_fluid_settings',None,[ptr])(settings)
# Gentle nylon-string background, retaining the user's supplied effects.
t=np.arange(len(mix))/sr;freq=np.fft.rfftfreq(len(t),1/sr)
eq=(1-np.exp(-(freq/90)**2))/np.sqrt(1+(freq/4200)**4)
for ch in range(2):mix[:,ch]=np.fft.irfft(np.fft.rfft(mix[:,ch])*eq,n=len(t))
rms=float(np.sqrt(np.mean(mix**2)));assert rms>0
mix*=.024/rms
peak=float(np.abs(mix).max())
if peak>.18:mix*=.18/peak
fade=np.sin(np.minimum(t/.6,1)*np.pi/2)**2*np.sin(np.minimum((15-t)/1.1,1)*np.pi/2)**2
# Light music ducking leaves space for each whoosh and the closing boom.
duck=np.ones(len(t))
for shot in C['shots'][1:]:duck-=.24*np.exp(-((t-shot['start_frame']/30)/.32)**2)
mix*=(fade*duck)[:,None]
music=P/'assets/audio/cozy-guitar-music.wav'
with wave.open(str(music),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
fx_path=P/'assets/audio/supplied-effects-mix.wav'
# Rebuild supplied effects if this project has been unpacked without generated WAVs.
if not fx_path.exists():subprocess.run([__import__('sys').executable,str(P/'supplied_effects.py')],check=True)
data=subprocess.check_output(['ffmpeg','-v','error','-i',str(fx_path),'-f','f32le','-ar',str(sr),'-ac','2','-'])
effects=np.frombuffer(data,dtype='<f4').reshape(-1,2);assert effects.shape==mix.shape
mix+=effects
assert float(np.abs(mix).max())<.95
raw=P/'assets/audio/cozy-music-effects-mix.wav'
with wave.open(str(raw),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
(P/'assets/audio/cozy-score.json').write_text(json.dumps({'notes':notes,'seed':617,'soundfont':'TimGM6mb.sf2','program':'Nylon string acoustic guitar, GM 24','piano':False,'music_ducking':'Gentle -24% envelope around the six transition centers','effects':'Original user-supplied whoosh and bass boom, existing timing preserved'},indent=2)+'\n')

normalized=P/'assets/audio/cozy-music-effects-master.wav'
first=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-20:TP=-2:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
stats,_=json.JSONDecoder().raw_decode(first[first.rfind('{'):])
normalizer='loudnorm=I=-20:TP=-2:LRA=8:linear=true:'+':'.join(['measured_I='+stats['input_i'],'measured_TP='+stats['input_tp'],'measured_LRA='+stats['input_lra'],'measured_thresh='+stats['input_thresh'],'offset='+stats['target_offset']])
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),'-af',normalizer,'-ar','48000','-c:a','pcm_s16le',str(normalized)],check=True)
video=P/'output/Prompolu_S140RP_Editorial_15s.mp4';out=P/'output/Prompolu_Infinity_15s_cozy_music.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(normalized),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart',str(out)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(out)]));v=next(s for s in info['streams'] if s['codec_type']=='video');a=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['nb_read_frames'],v['r_frame_rate'])==(1080,1920,'450','30/1')
assert a['codec_name']=='aac' and a['channels']==2 and a['sample_rate']=='48000'
assert abs(float(info['format']['duration'])-15)<.001
subprocess.run(['ffmpeg','-xerror','-v','error','-i',str(out),'-f','null','-'],check=True)
# Confirm bit-for-bit preservation of the compressed H.264 video stream.
def video_hash(path):
 return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-']).decode().strip()
assert video_hash(video)==video_hash(out)
measure=subprocess.run(['ffmpeg','-hide_banner','-i',str(out),'-af','loudnorm=I=-20:TP=-2:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
loudness,_=json.JSONDecoder().raw_decode(measure[measure.rfind('{'):]);assert float(loudness['input_tp'])<-1
report={'status':'passed','duration':15,'frames':450,'audio':'AAC stereo 48 kHz','video_bitstream_unchanged':True,'full_decode':'passed','loudness_lufs':float(loudness['input_i']),'true_peak_dbtp':float(loudness['input_tp']),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(P/'output/cozy-music-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
