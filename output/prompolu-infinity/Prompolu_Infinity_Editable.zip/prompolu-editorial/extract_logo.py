"""Extract the supplied PDF's first-page primary logo without generative editing."""
from pathlib import Path
import subprocess
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent/'assets'
subprocess.run(['pdftoppm','-f','1','-singlefile','-scale-to','3200','-png',str(P/'brand-source.pdf'),str(P/'logo-page')],check=True)
a=np.array(Image.open(P/'logo-page.png').convert('RGB').crop((220,570,1690,810)))
alpha=(255-a.min(axis=2)).astype('uint8');alpha[alpha<20]=0
rgba=np.zeros((*alpha.shape,4),dtype='uint8');rgba[:,:,:3]=[21,23,26];rgba[:,:,3]=alpha
im=Image.fromarray(rgba);im.crop(im.getbbox()).save(P/'logo-prompolu.png')
