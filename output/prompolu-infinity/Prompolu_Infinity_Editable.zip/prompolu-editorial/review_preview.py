from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw
import numpy as np
P=Path(__file__).resolve().parent
c=json.loads((P/'timeline.json').read_text());chosen={}
for row,s in enumerate(c['shots'][1:]):
 for col,off in enumerate([-8,-1,3,9,18]):chosen[s['start_frame']+off]=(col,row)
proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(P/'previews/preview.mp4'),'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
sheet=Image.new('RGB',(5*216,6*410),'#eeeeea');scores=[];n=0;prev=None
while True:
 data=proc.stdout.read(540*960*3)
 if not data:break
 assert len(data)==540*960*3
 a=np.frombuffer(data,dtype=np.uint8).reshape(960,540,3);scores.append(float(a.mean()))
 if n in chosen:
  x,y=chosen[n];im=Image.fromarray(a).resize((216,384));sheet.paste(im,(x*216,y*410));ImageDraw.Draw(sheet).text((x*216+5,y*410+385),f'frame {n}',fill='black')
 n+=1
assert proc.wait()==0 and n==450 and min(scores)>80
sheet.save(P/'previews/transitions.jpg',quality=94)
print('Decoded all 450 preview frames; no black/blank frame; transition sheet saved.')
