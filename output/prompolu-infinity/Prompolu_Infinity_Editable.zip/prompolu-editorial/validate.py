from pathlib import Path
import json,subprocess,hashlib
P=Path(__file__).resolve().parent
f=P/'output/Prompolu_S140RP_Editorial_15s.mp4'
r=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]))
s=r['streams'];assert len(s)==1
v=s[0];assert (v['width'],v['height'])==(1080,1920)
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p'
assert v['r_frame_rate']=='30/1' and int(v['nb_read_frames'])==450
assert abs(float(r['format']['duration'])-15)<.0001
subprocess.run(['ffmpeg','-xerror','-v','error','-i',str(f),'-f','null','-'],check=True)
b=f.read_bytes();assert b.find(b'moov')<b.find(b'mdat')
report={'status':'passed','width':1080,'height':1920,'fps':30,'frames':450,'duration':15,'codec':'h264','pixel_format':'yuv420p','audio':False,'full_decode':'passed','fast_start':True,'sha256':hashlib.sha256(b).hexdigest()}
(P/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
