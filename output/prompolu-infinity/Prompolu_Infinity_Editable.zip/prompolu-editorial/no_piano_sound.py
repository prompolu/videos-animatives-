"""Original airy ambient sound design: no piano, keyboard, melody or voice."""
from pathlib import Path
import json,subprocess,wave,hashlib
import numpy as np
P=Path(__file__).resolve().parent
C=json.loads((P/'timeline.json').read_text());sr=48000;duration=15
n=sr*15;t=np.arange(n)/sr;rng=np.random.default_rng(814);mix=np.zeros((n,2))
freq=np.fft.rfftfreq(n,1/sr)
def texture(center,width):
 noise=rng.normal(size=n);spectrum=np.fft.rfft(noise)
 spectrum*=np.exp(-((freq-center)/width)**2)*(1-np.exp(-(freq/120)**4))
 a=np.fft.irfft(spectrum,n=n);return a/max(1e-9,np.std(a))
# Warm, non-tonal room-like air with slow, non-periodic fluctuations.
for channel in range(2):
 air=texture(390,390)
 motion=.62+.10*np.sin(2*np.pi*.11*t+channel*.7)+.06*np.sin(2*np.pi*.23*t+1.4)
 mix[:,channel]+=air*.017*motion
# Different understated swells lead the six visual transitions.
for i,shot in enumerate(C['shots'][1:]):
 at=shot['start_frame']/30
 center=[700,1050,520,850,420,600][i];width=[500,650,400,550,350,450][i]
 air=texture(center,width)
 env=np.exp(-((t-(at-.025))/(.23 if i%2 else .29))**2)
 pan=.18*np.sin((t-at)*2.2+i)
 level=[.032,.025,.023,.026,.024,.020][i]
 mix[:,0]+=air*env*level*(1-pan)
 mix[:,1]+=air*env*level*(1+pan)
# Short diffuse room reflections; no rhythmic beat or tonal note.
for delay,level in [(.047,.11),(.083,.075),(.139,.045)]:
 d=round(sr*delay);mix[d:]+=mix[:-d,::-1]*level
fade=np.sin(np.minimum(t/.7,1)*np.pi/2)**2*np.sin(np.minimum((15-t)/1.0,1)*np.pi/2)**2
mix*=fade[:,None];mix*=.42/max(1e-9,float(np.abs(mix).max()))
raw=P/'assets/audio/ambient-no-piano-original.wav'
with wave.open(str(raw),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())

normalized=P/'assets/audio/ambient-no-piano-master.wav'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),'-af','loudnorm=I=-23:TP=-3:LRA=8','-ar','48000','-c:a','pcm_s16le',str(normalized)],check=True)
video=P/'output/Prompolu_S140RP_Editorial_15s.mp4';out=P/'output/Prompolu_Infinity_15s_sans_piano.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(normalized),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart',str(out)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(out)]));v=next(s for s in info['streams'] if s['codec_type']=='video');a=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['nb_read_frames'],v['r_frame_rate'])==(1080,1920,'450','30/1')
assert a['codec_name']=='aac' and a['channels']==2 and a['sample_rate']=='48000'
assert abs(float(info['format']['duration'])-15)<.001
subprocess.run(['ffmpeg','-xerror','-v','error','-i',str(out),'-f','null','-'],check=True)
# Confirm bit-for-bit preservation of the compressed H.264 video stream.
def video_hash(path):
 return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-']).decode().strip()
assert video_hash(video)==video_hash(out)
measure=subprocess.run(['ffmpeg','-hide_banner','-i',str(out),'-af','loudnorm=I=-23:TP=-3:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
loudness,_=json.JSONDecoder().raw_decode(measure[measure.rfind('{'):]);assert float(loudness['input_tp'])<-1
report={'status':'passed','duration':15,'frames':450,'audio':'AAC stereo 48 kHz','video_bitstream_unchanged':True,'full_decode':'passed','loudness_lufs':float(loudness['input_i']),'true_peak_dbtp':float(loudness['input_tp']),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(P/'output/no-piano-audio-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
