"""Mix the user's two supplied MP3 effects, synced to the existing edit."""
from pathlib import Path
import json,subprocess,wave,hashlib
import numpy as np
P=Path(__file__).resolve().parent
C=json.loads((P/'timeline.json').read_text());sr=48000;duration=15
mix=np.zeros((sr*15,2));schedule=[]
def read(name):
 path=P/'assets/audio/supplied'/name
 data=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-f','f32le','-ar',str(sr),'-ac','2','-'])
 a=np.frombuffer(data,dtype='<f4').reshape(-1,2).astype(float)
 peak=float(np.abs(a).max());assert peak>0;a/=peak
 energy=np.mean(a*a,axis=1);block=960
 # Strongest 20 ms window, aligned to the visual transition's midpoint.
 energies=np.array([energy[i:i+block].mean() for i in range(0,len(a),block)])
 at=(int(energies.argmax())*block+block/2)/sr
 # Tiny edge fades prevent discontinuities at decoded sample boundaries.
 fade=np.minimum(np.arange(len(a))/(sr*.005),1)*np.minimum(np.arange(len(a))[::-1]/(sr*.012),1)
 a*=fade[:,None]
 return a,at,path
whoosh,whoosh_peak,whoosh_path=read('dragon-studio-simple-whoosh-382724.mp3')
boom,boom_peak,boom_path=read('alexis_gaming_cam-cinematic-bass-boom-free-370400.mp3')
def place(a,peak,time,level,pan,label):
 start=round((time-peak)*sr);offset=max(0,-start);dest=max(start,0);count=min(len(a)-offset,len(mix)-dest)
 if count<=0:return
 source=a[offset:offset+count].copy();source[:,0]*=1-pan;source[:,1]*=1+pan
 mix[dest:dest+count]+=source*level
 schedule.append({'effect':label,'peak_aligned_seconds':time,'start_seconds':round(start/sr,4),'relative_peak_gain':level,'pan':pan})
for i,shot in enumerate(C['shots'][1:]):
 place(whoosh,whoosh_peak,shot['start_frame']/30,[.23,.21,.19,.21,.20,.15][i],[0,.12,-.1,.1,-.08,0][i],'whoosh')
place(boom,boom_peak,12.9,.34,0,'bass_boom')
# The 7.6-second boom tail is shortened to fit the 15-second edit, with a gentle ending.
t=np.arange(len(mix))/sr;fade=np.sin(np.minimum((15-t)/.7,1)*np.pi/2)**2;mix*=fade[:,None]
assert float(np.abs(mix).max())<1
raw=P/'assets/audio/supplied-effects-mix.wav'
with wave.open(str(raw),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
(P/'assets/audio/supplied-effects-cues.json').write_text(json.dumps({'schedule':schedule,'sources':[{'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'provenance':'Fichier fourni par utilisateur'} for f in [whoosh_path,boom_path]],'piano':False,'music':False,'other_effects':False,'boom_tail':'Fondu doux sur les 0,7 dernières secondes pour tenir dans le montage de 15 s'},ensure_ascii=False,indent=2)+'\n')

normalized=P/'assets/audio/supplied-effects-master.wav'
first=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-20:TP=-2:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
stats,_=json.JSONDecoder().raw_decode(first[first.rfind('{'):])
normalizer='loudnorm=I=-20:TP=-2:LRA=8:linear=true:'+':'.join(['measured_I='+stats['input_i'],'measured_TP='+stats['input_tp'],'measured_LRA='+stats['input_lra'],'measured_thresh='+stats['input_thresh'],'offset='+stats['target_offset']])
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),'-af',normalizer,'-ar','48000','-c:a','pcm_s16le',str(normalized)],check=True)
video=P/'output/Prompolu_S140RP_Editorial_15s.mp4';out=P/'output/Prompolu_Infinity_15s_effets_fournis.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(normalized),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart',str(out)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(out)]));v=next(s for s in info['streams'] if s['codec_type']=='video');a=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['nb_read_frames'],v['r_frame_rate'])==(1080,1920,'450','30/1')
assert a['codec_name']=='aac' and a['channels']==2 and a['sample_rate']=='48000'
assert abs(float(info['format']['duration'])-15)<.001
subprocess.run(['ffmpeg','-xerror','-v','error','-i',str(out),'-f','null','-'],check=True)
# Confirm bit-for-bit preservation of the compressed H.264 video stream.
def video_hash(path):
 return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-']).decode().strip()
assert video_hash(video)==video_hash(out)
measure=subprocess.run(['ffmpeg','-hide_banner','-i',str(out),'-af','loudnorm=I=-20:TP=-2:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
loudness,_=json.JSONDecoder().raw_decode(measure[measure.rfind('{'):]);assert float(loudness['input_tp'])<-1
report={'status':'passed','duration':15,'frames':450,'audio':'AAC stereo 48 kHz','video_bitstream_unchanged':True,'full_decode':'passed','loudness_lufs':float(loudness['input_i']),'true_peak_dbtp':float(loudness['input_tp']),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(P/'output/supplied-effects-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
