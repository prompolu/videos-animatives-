from pathlib import Path
import argparse, json, math, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps
P=Path(__file__).resolve().parent
C=json.loads((P/'timeline.json').read_text()); W,H=1080,1920
def rgb(value):return tuple(bytes.fromhex(value.lstrip('#')))
INK=rgb(C['colors']['charcoal']); PAPER=rgb(C['colors']['paper']); BRONZE=rgb(C['colors']['bronze'])
F=str(P/'assets/fonts')+'/'
FONT={'sans':F+'DejaVuSans-ExtraLight.ttf','italic':F+'DejaVuSans-Oblique.ttf','serif':F+'DejaVuSerif-Italic.ttf','label':F+'DejaVuSans.ttf'}
def smooth(x):
 x=min(1,max(0,x));return x*x*(3-2*x)
def architecture(kind):
 # Original conceptual illustrations, not photographs or real PROMPOLU projects.
 w,h=900,1200;y=np.linspace(0,1,h)[:,None,None]; top=np.array([192,207,210]); bottom=np.array(PAPER)
 ar=np.repeat((top[None,None,:]*(1-y)+bottom[None,None,:]*y),w,axis=1).astype('uint8');im=Image.fromarray(ar);d=ImageDraw.Draw(im)
 if kind==0:
  d.rectangle((0,750,900,1200),fill='#C7C3B8')
  d.polygon([(40,270),(740,180),(900,270),(900,1020),(40,1080)],fill='#E6E3DA')
  d.polygon([(740,180),(900,270),(900,1020),(740,940)],fill='#C2BFB5')
  d.polygon([(90,380),(700,310),(700,900),(90,980)],fill='#273235')
  for j in range(4):
   x=105+j*148;d.polygon([(x,395-j*16),(x+130,380-j*16),(x+130,900-j*17),(x,920-j*17)],fill=('#7D9599' if j%2 else '#A2B4B5'))
   d.polygon([(x+9,430-j*16),(x+44,420-j*16),(x+105,865-j*17),(x+80,875-j*17)],fill='#BBCAC8')
  d.polygon([(10,230),(755,130),(900,210),(900,275),(750,230),(10,330)],fill='#F2F0E9')
  d.rectangle((80,1000,700,1025),fill='#8B8170')
 elif kind==1:
  d.rectangle((0,0,900,1200),fill='#DDDAD1');d.polygon([(0,0),(900,0),(900,110),(150,270)],fill='#F7F5EF')
  d.rectangle((100,280,820,940),fill='#394344');d.rectangle((118,298,802,920),fill='#BDCED0')
  d.rectangle((118,660,802,920),fill='#B2B7A1')
  for x in [340,575]:d.rectangle((x,285,x+12,940),fill='#3A3D3B')
  d.polygon([(0,1200),(900,1200),(900,940),(0,940)],fill='#B5A48B')
  for x in range(-500,1700,170):d.line((450,940,x,1200),fill='#C6B69E',width=3)
  d.polygon([(80,940),(240,940),(670,1200),(340,1200)],fill='#E8E3D1')
  d.rounded_rectangle((50,860,295,1060),radius=25,fill='#EDE8DD');d.rectangle((60,1025,85,1120),fill='#756C5B')
  d.ellipse((680,900,810,960),fill='#A89B80');d.rectangle((700,940,785,1080),fill='#B1A38B')
 else:
  d.rectangle((0,0,900,1200),fill='#E5E2D8');d.rectangle((100,240,830,960),fill='#343A39');d.rectangle((117,258,812,945),fill='#B7C9CD')
  d.rectangle((117,650,812,945),fill='#A4AD92');d.rectangle((117,750,812,945),fill='#C6C0AD')
  for yv in range(790,950,34):d.line((117,yv,812,yv),fill='#B3A58F',width=3)
  for x in [350,590]:d.rectangle((x,250,x+15,955),fill='#404441')
  d.polygon([(0,1200),(900,1200),(900,960),(0,960)],fill='#D6CDBB')
  d.rectangle((660,720,800,850),fill='#687B61');d.rectangle((695,830,765,940),fill='#AA977A')
  d.rectangle((165,680,280,850),fill='#7D8F71');d.rectangle((190,830,255,935),fill='#A89880')
 # fine texture and a soft light wash
 a=np.array(im).astype(float);rng=np.random.default_rng(40+kind);a+=rng.normal(0,.65,a.shape[:2])[:,:,None];return Image.fromarray(np.clip(a,0,255).astype('uint8'))
def prepare():
 for i in range(3):architecture(i).save(P/'assets'/f'architecture-{i+1}.jpg',quality=96)
class Renderer:
 def __init__(self,scale):
  self.s=scale;self.w=round(W*scale);self.h=round(H*scale);self.fonts={}
  yy,xx=np.mgrid[:self.h,:self.w];r=((xx/self.w-.5)**2+((yy/self.h-.42)*.75)**2)
  a=np.array(PAPER)[None,None,:]+(1-r[:,:,None]*2.2)*5
  self.bg=Image.fromarray(np.clip(a,0,255).astype('uint8')).convert('RGBA')
  self.product=Image.open(P/'assets/product.png').convert('RGBA');bb=self.product.getbbox();self.product=self.product.crop(bb)
  self.cards=[Image.open(P/'assets'/f'architecture-{i+1}.jpg').convert('RGBA') for i in range(3)]
 def font(self,key,size):
  k=(key,size)
  if k not in self.fonts:self.fonts[k]=ImageFont.truetype(FONT[key],max(1,round(size*self.s)))
  return self.fonts[k]
 def text(self,im,text,x,y,key,size,color=INK,alpha=1):
  layer=Image.new('RGBA',im.size);d=ImageDraw.Draw(layer);font=self.font(key,size)
  # Fit phrases within safe margins while preserving hierarchy.
  maxwidth=880*self.s
  while d.textlength(text,font=font)>maxwidth and size>28:size-=1;font=self.font(key,size)
  d.text((round(x*self.s),round(y*self.s)),text,font=font,fill=(*color,round(255*alpha)),stroke_width=0)
  im.alpha_composite(layer)
 def paste(self,im,asset,x,y,w,h,opacity=1,rounded=0,shadow=True):
  size=(max(1,round(w*self.s)),max(1,round(h*self.s)))
  pic=ImageOps.fit(asset,size,method=Image.Resampling.LANCZOS) if rounded else ImageOps.contain(asset,size,method=Image.Resampling.LANCZOS)
  if rounded:
   mask=Image.new('L',pic.size);ImageDraw.Draw(mask).rounded_rectangle((0,0,pic.width-1,pic.height-1),radius=rounded*self.s,fill=255);pic.putalpha(mask)
  px=round(x*self.s)+(size[0]-pic.width)//2;py=round(y*self.s)+(size[1]-pic.height)//2
  if shadow:
   sh=Image.new('RGBA',im.size);sil=Image.new('RGBA',pic.size,(21,23,26,0));sil.putalpha(pic.getchannel('A').point(lambda v:round(v*.17*opacity)));sh.paste(sil,(px+round(12*self.s),py+round(34*self.s)));im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(24*self.s)))
  if opacity<1:pic.putalpha(pic.getchannel('A').point(lambda a:round(a*opacity)))
  im.alpha_composite(pic,(px,py))
 def background(self,t):
  im=self.bg.copy();d=ImageDraw.Draw(im)
  # broad flowing Bezier ribbon behind all subjects
  pts=[];drift=math.sin(t*.24)*60
  for i in range(81):
   u=i/80;x=-200+1480*u;y=1150+drift+230*math.sin(u*math.pi*1.65+t*.07);pts.append((round(x*self.s),round(y*self.s)))
  layer=Image.new('RGBA',im.size);ld=ImageDraw.Draw(layer);ld.line(pts,fill=(*BRONZE,160),width=round(105*self.s),joint='curve');im.alpha_composite(layer)
  # abstract technical watermark, derived from the supplied product alpha silhouette
  mark=self.product.copy();mark=ImageOps.contain(mark,(round(1300*self.s),round(1300*self.s)));alpha=mark.getchannel('A').point(lambda v:round(v*.045));mark=Image.new('RGBA',mark.size,INK);mark.putalpha(alpha);im.alpha_composite(mark,(round(270*self.s),round(390*self.s)))
  deco=Image.new('RGBA',im.size);dd=ImageDraw.Draw(deco);dd.rounded_rectangle((-100*self.s,400*self.s,20*self.s,900*self.s),radius=30*self.s,fill=(*INK,55));dd.ellipse((1000*self.s,1440*self.s,1190*self.s,1800*self.s),fill=(*INK,50));im.alpha_composite(deco.filter(ImageFilter.GaussianBlur(18*self.s)))
  self.text(im,'PROMPOLU',96,185,'label',30,INK,.8)
  return im
 def shot(self,i,local,t):
  copy=C['shots'][i]['text'];im=self.background(t);enter=smooth(local/.55);dy=(1-enter)*65; a=smooth(local/.3)
  second=smooth((local-.12)/.35)
  if i==0:
   self.text(im,copy[0],96,320+dy,'italic',66,alpha=a);self.text(im,copy[1],96,412+dy,'serif',110,alpha=second)
   self.paste(im,self.product,165,665+dy,750*(1+.025*local),1000,enter)
  elif i==1:
   self.text(im,copy[0],96,320+dy,'italic',74,alpha=a);self.text(im,copy[1],96,420+dy,'serif',116,alpha=second)
   # crop solely the original image for detail, never synthesize extra geometry
   p=self.product;detail=p.crop((0,0,p.width,round(p.height*.52)))
   self.paste(im,detail,105,760+dy,870,740,enter)
   d=ImageDraw.Draw(im);cx,cy=560*self.s,1110*self.s;r=260*self.s
   for j in range(64):
    ang=j*2*math.pi/64;rr=2.2*self.s;x=cx+r*math.cos(ang);y=cy+r*math.sin(ang);d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=(*BRONZE,round(255*second)))
  elif i in (2,3,4):
   self.paste(im,self.cards[i-2],140,530+dy,800,1100,enter,44)
   if i==2:
    self.text(im,copy[0],96,300+dy,'italic',60,alpha=a);self.text(im,copy[1],96,390+dy,'serif',106,alpha=second)
   elif i==3:self.text(im,copy[0],96,345+dy,'serif',105,alpha=a)
   else:self.text(im,copy[0],96,300+dy,'italic',68,alpha=a);self.text(im,copy[1],96,395+dy,'serif',110,alpha=second)
   self.text(im,'Illustration architecturale • vue conceptuelle',145,1652,'label',25,INK,enter*.7)
  elif i==5:
   self.paste(im,self.product,-410,730+dy,1080*(1+.035*local),1270,enter)
   self.text(im,copy[0],96,330+dy,'italic',73,alpha=a);self.text(im,copy[1],96,430+dy,'serif',106,alpha=second)
  else:
   self.text(im,'PROMPOLU',96,380+dy,'label',100,alpha=a)
   self.text(im,copy[1],96,530+dy,'sans',58,alpha=second)
   self.text(im,copy[2],96,635+dy,'label',38,alpha=second)
   self.paste(im,self.product,250,840+dy,580,680,enter)
   self.text(im,'Donnez forme à vos projets.',96,1585,'serif',52,alpha=second)
  return im
 def frame(self,n):
  t=n/30;shots=C['shots'];i=max(i for i,v in enumerate(shots) if n>=v['start_frame']);start=shots[i]['start_frame']/30
  im=self.shot(i,t-start,t)
  if i and n-shots[i]['start_frame']<10:
   prev=self.shot(i-1,t-shots[i-1]['start_frame']/30,t);im=Image.blend(prev,im,smooth((n-shots[i]['start_frame'])/10))
  return im.convert('RGB')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preview',action='store_true');ap.add_argument('--stills',action='store_true');args=ap.parse_args();prepare()
 r=Renderer(.5 if args.preview else 1)
 if args.stills:
  thumb=Image.new('RGB',(7*270,480),PAPER)
  for i,s in enumerate(C['shots']):
   n=min(s['end_frame_exclusive']-1,s['start_frame']+30);im=r.frame(n);im.save(P/'previews'/f'shot-{i+1}.png');thumb.paste(im.resize((270,480)),(i*270,0))
  thumb.save(P/'previews/storyboard.jpg',quality=95);return
 out=P/('previews/preview.mp4' if args.preview else 'output/Prompolu_S140RP_Editorial_15s.mp4')
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{r.w}x{r.h}','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-threads','3','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 try:
  for n in range(450):
   proc.stdin.write(r.frame(n).tobytes())
   if n%90==0:print(f'{n}/450',flush=True)
 finally:proc.stdin.close()
 if proc.wait()!=0:raise RuntimeError('FFmpeg failed')
 print(out,flush=True)
if __name__=='__main__':main()
