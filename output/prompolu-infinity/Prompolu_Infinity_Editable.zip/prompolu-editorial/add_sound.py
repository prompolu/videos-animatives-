"""Compose an original soundtrack locally and mux without re-encoding video."""
from pathlib import Path
import json, subprocess, wave, hashlib
import numpy as np
P=Path(__file__).resolve().parent
C=json.loads((P/'timeline.json').read_text());sr=48000;duration=C['frames']/C['fps']
t=np.arange(round(sr*duration))/sr;mix=np.zeros((len(t),2));rng=np.random.default_rng(140)
def add(signal,pan=0):
 mix[:,0][:]+=signal*np.sqrt((1-pan)/2);mix[:,1][:]+=signal*np.sqrt((1+pan)/2)
def note(freq,start,length,level=.07,pan=0):
 u=t-start;z=np.maximum(u,0);env=(1-np.exp(-z*100))*np.exp(-z*1.8)*np.clip((length-z)/.35,0,1)*(u>=0)
 sig=np.sin(2*np.pi*freq*z)+.22*np.sin(2*np.pi*freq*2*z)*np.exp(-z*4)+.07*np.sin(2*np.pi*freq*3*z)*np.exp(-z*7)
 add(sig*env*level,pan)
chords=[(0,3.75,[146.832,174.614,220]),(3.75,3.75,[116.541,146.832,174.614]),(7.5,3.75,[130.813,174.614,220]),(11.25,3.75,[146.832,174.614,220])]
for start,length,notes in chords:
 u=t-start;z=np.clip(u,0,length);env=np.sin(np.pi*z/length)**1.2
 for j,f in enumerate(notes):
  add((np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*(f*1.001)*t))*.025*env,(j-1)*.3)
 for j,f in enumerate(notes*2):note(f*2,start+.25+j*.55,2,.06,(j%3-1)*.35)
 # Rounded bass without a heavy dance beat.
 for pos in np.arange(start,start+length,.625):
  z=np.maximum(0,t-pos);env=(t>=pos)*np.exp(-z*10)*(1-np.exp(-z*100))
  add(.055*np.sin(2*np.pi*(notes[0]/2)*z)*env)
# Soft transition air, generated from filtered noise, not an external sample.
noise=rng.normal(size=len(t));spec=np.fft.rfft(noise);freq=np.fft.rfftfreq(len(t),1/sr)
spec*=np.exp(-((freq-1600)/1300)**2)*(freq>220)
air=np.fft.irfft(spec,n=len(t));air/=max(1e-6,np.std(air))
for i,shot in enumerate(C['shots'][1:]):
 at=shot['start_frame']/30;env=np.exp(-((t-(at-.06))/.17)**2)
 add(air*env*.018,(-1 if i%2 else 1)*.25)
# A restrained closing chime under the brand card.
for j,f in enumerate([293.665,349.228,440]):note(f,12.9+j*.09,2.1,.045,(j-1)*.25)
fade=np.minimum(t/.55,1)*np.minimum((duration-t)/.85,1);mix*=fade[:,None]
peak=float(np.max(np.abs(mix)));mix*=.6/max(peak,1e-8)
raw=P/'assets/original-soundtrack.wav'
with wave.open(str(raw),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
normalized=P/'assets/soundtrack-master.wav'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),'-af','loudnorm=I=-18:TP=-2:LRA=7','-ar','48000','-c:a','pcm_s16le',str(normalized)],check=True)
video=P/'output/Prompolu_S140RP_Editorial_15s.mp4';out=P/'output/Prompolu_Infinity_15s_avec_son.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(normalized),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart',str(out)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(out)]));v=next(s for s in info['streams'] if s['codec_type']=='video');a=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['nb_read_frames'],v['r_frame_rate'])==(1080,1920,'450','30/1')
assert a['codec_name']=='aac' and a['channels']==2 and a['sample_rate']=='48000'
assert abs(float(info['format']['duration'])-15)<.001
subprocess.run(['ffmpeg','-xerror','-v','error','-i',str(out),'-f','null','-'],check=True)
# Confirm bit-for-bit preservation of the compressed H.264 video stream.
def video_hash(path):
 return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-']).decode().strip()
assert video_hash(video)==video_hash(out)
measure=subprocess.run(['ffmpeg','-hide_banner','-i',str(out),'-af','loudnorm=I=-18:TP=-2:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
loudness,_=json.JSONDecoder().raw_decode(measure[measure.rfind('{'):]);assert float(loudness['input_tp'])<-1
report={'status':'passed','duration':15,'frames':450,'audio':'AAC stereo 48 kHz','video_bitstream_unchanged':True,'full_decode':'passed','loudness_lufs':float(loudness['input_i']),'true_peak_dbtp':float(loudness['input_tp']),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(P/'output/audio-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
